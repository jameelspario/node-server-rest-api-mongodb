const express = require("express")
const mongoose = require('mongoose')

// import router
const authRouter = require("./routes/auth")



const PORT = 3000;
const app = express();
const DB = "mongodb+srv://spario:0gd97959391@cluster0.dpiprsi.mongodb.net/?retryWrites=true&w=majority"


//moddleware
app.use(express.json())
app.use(authRouter)

/// home route
// app.get('/', (req, res)=>{
//     console.log("get")
//     // res.send("hello")
//     res.json({name:"jameel"})
// })

////connstion
mongoose.connect(DB)
.then(()=>{
    console.log("conntection success")
})
.catch((e)=>{
    console.log(e)
})


app.listen(PORT, ()=>{
    console.log(`connected ${PORT}`)
})