const mongoose = require('mongoose')

const userSchema = mongoose.Schema({
    name:{
        required:true,
        type:String,
        trim:true,
    },
    email:{
        required:true,
        type:String,
        trim:true,
        // validate:{
        //     valodator:(val)=>{
        //         const r = "^\w+[\w-\.]*\@\w+((-\w+)|(\w*))\.[a-z]{2,3}$"
        //         return val.match(re)
        //     },
        //     massage:"please enter a valid email",

        // }
    },
    password:{
        required:true,
        type:String,
    },
    address:{
        type:String,
        default:'',
    },
    type:{
        type:String,
        default:'user',
    }


})

const User = mongoose.model("User", userSchema)
module.exports = User
